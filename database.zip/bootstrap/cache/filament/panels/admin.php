<?php return array (
  'livewireComponents' => 
  array (
    'app.filament.resources.guru-resource.pages.create-guru' => 'App\\Filament\\Resources\\GuruResource\\Pages\\CreateGuru',
    'app.filament.resources.guru-resource.pages.edit-guru' => 'App\\Filament\\Resources\\GuruResource\\Pages\\EditGuru',
    'app.filament.resources.guru-resource.pages.list-gurus' => 'App\\Filament\\Resources\\GuruResource\\Pages\\ListGurus',
    'app.filament.resources.jad-bel-resource.pages.create-jad-bel' => 'App\\Filament\\Resources\\JadBelResource\\Pages\\CreateJadBel',
    'app.filament.resources.jad-bel-resource.pages.edit-jad-bel' => 'App\\Filament\\Resources\\JadBelResource\\Pages\\EditJadBel',
    'app.filament.resources.jad-bel-resource.pages.list-jad-bels' => 'App\\Filament\\Resources\\JadBelResource\\Pages\\ListJadBels',
    'app.filament.resources.kelas-resource.pages.create-kelas' => 'App\\Filament\\Resources\\KelasResource\\Pages\\CreateKelas',
    'app.filament.resources.kelas-resource.pages.edit-kelas' => 'App\\Filament\\Resources\\KelasResource\\Pages\\EditKelas',
    'app.filament.resources.kelas-resource.pages.list-kelas' => 'App\\Filament\\Resources\\KelasResource\\Pages\\ListKelas',
    'app.filament.resources.pekerjaan-resource.pages.create-pekerjaan' => 'App\\Filament\\Resources\\PekerjaanResource\\Pages\\CreatePekerjaan',
    'app.filament.resources.pekerjaan-resource.pages.edit-pekerjaan' => 'App\\Filament\\Resources\\PekerjaanResource\\Pages\\EditPekerjaan',
    'app.filament.resources.pekerjaan-resource.pages.list-pekerjaans' => 'App\\Filament\\Resources\\PekerjaanResource\\Pages\\ListPekerjaans',
    'app.filament.resources.periode-resource.pages.create-periode' => 'App\\Filament\\Resources\\PeriodeResource\\Pages\\CreatePeriode',
    'app.filament.resources.periode-resource.pages.edit-periode' => 'App\\Filament\\Resources\\PeriodeResource\\Pages\\EditPeriode',
    'app.filament.resources.periode-resource.pages.list-periodes' => 'App\\Filament\\Resources\\PeriodeResource\\Pages\\ListPeriodes',
    'app.filament.resources.santri-resource.pages.create-santri' => 'App\\Filament\\Resources\\SantriResource\\Pages\\CreateSantri',
    'app.filament.resources.santri-resource.pages.edit-santri' => 'App\\Filament\\Resources\\SantriResource\\Pages\\EditSantri',
    'app.filament.resources.santri-resource.pages.list-santris' => 'App\\Filament\\Resources\\SantriResource\\Pages\\ListSantris',
    'app.filament.resources.santri-resource.pages.show-santri' => 'App\\Filament\\Resources\\SantriResource\\Pages\\ShowSantri',
    'app.filament.resources.user-resource.pages.create-user' => 'App\\Filament\\Resources\\UserResource\\Pages\\CreateUser',
    'app.filament.resources.user-resource.pages.edit-user' => 'App\\Filament\\Resources\\UserResource\\Pages\\EditUser',
    'app.filament.resources.user-resource.pages.list-users' => 'App\\Filament\\Resources\\UserResource\\Pages\\ListUsers',
    'app.filament.pages.dashboard' => 'App\\Filament\\Pages\\Dashboard',
    'app.filament.widgets.guru-chart' => 'App\\Filament\\Widgets\\GuruChart',
    'app.filament.widgets.santri-chart' => 'App\\Filament\\Widgets\\SantriChart',
    'app.filament.widgets.stats-overview' => 'App\\Filament\\Widgets\\StatsOverview',
    'filament.widgets.account-widget' => 'Filament\\Widgets\\AccountWidget',
    'filament.widgets.filament-info-widget' => 'Filament\\Widgets\\FilamentInfoWidget',
    'filament.livewire.database-notifications' => 'Filament\\Livewire\\DatabaseNotifications',
    'filament.pages.auth.edit-profile' => 'Filament\\Pages\\Auth\\EditProfile',
    'filament.livewire.global-search' => 'Filament\\Livewire\\GlobalSearch',
    'filament.livewire.notifications' => 'Filament\\Livewire\\Notifications',
    'filament.pages.auth.email-verification.email-verification-prompt' => 'Filament\\Pages\\Auth\\EmailVerification\\EmailVerificationPrompt',
    'filament.pages.auth.login' => 'Filament\\Pages\\Auth\\Login',
    'filament.pages.auth.register' => 'Filament\\Pages\\Auth\\Register',
    'bezhan-salleh.filament-shield.resources.role-resource.pages.list-roles' => 'BezhanSalleh\\FilamentShield\\Resources\\RoleResource\\Pages\\ListRoles',
    'bezhan-salleh.filament-shield.resources.role-resource.pages.create-role' => 'BezhanSalleh\\FilamentShield\\Resources\\RoleResource\\Pages\\CreateRole',
    'bezhan-salleh.filament-shield.resources.role-resource.pages.view-role' => 'BezhanSalleh\\FilamentShield\\Resources\\RoleResource\\Pages\\ViewRole',
    'bezhan-salleh.filament-shield.resources.role-resource.pages.edit-role' => 'BezhanSalleh\\FilamentShield\\Resources\\RoleResource\\Pages\\EditRole',
  ),
  'clusters' => 
  array (
  ),
  'clusteredComponents' => 
  array (
  ),
  'clusterDirectories' => 
  array (
  ),
  'clusterNamespaces' => 
  array (
  ),
  'pages' => 
  array (
    'C:\\xampp\\htdocs\\Sistem-Management-Masjid\\app\\Filament\\Pages\\Dashboard.php' => 'App\\Filament\\Pages\\Dashboard',
  ),
  'pageDirectories' => 
  array (
    0 => 'C:\\xampp\\htdocs\\Sistem-Management-Masjid\\app\\Filament/Pages',
  ),
  'pageNamespaces' => 
  array (
    0 => 'App\\Filament\\Pages',
  ),
  'resources' => 
  array (
    'C:\\xampp\\htdocs\\Sistem-Management-Masjid\\app\\Filament\\Resources\\GuruResource.php' => 'App\\Filament\\Resources\\GuruResource',
    'C:\\xampp\\htdocs\\Sistem-Management-Masjid\\app\\Filament\\Resources\\JadBelResource.php' => 'App\\Filament\\Resources\\JadBelResource',
    'C:\\xampp\\htdocs\\Sistem-Management-Masjid\\app\\Filament\\Resources\\KelasResource.php' => 'App\\Filament\\Resources\\KelasResource',
    'C:\\xampp\\htdocs\\Sistem-Management-Masjid\\app\\Filament\\Resources\\PekerjaanResource.php' => 'App\\Filament\\Resources\\PekerjaanResource',
    'C:\\xampp\\htdocs\\Sistem-Management-Masjid\\app\\Filament\\Resources\\PeriodeResource.php' => 'App\\Filament\\Resources\\PeriodeResource',
    'C:\\xampp\\htdocs\\Sistem-Management-Masjid\\app\\Filament\\Resources\\SantriResource.php' => 'App\\Filament\\Resources\\SantriResource',
    'C:\\xampp\\htdocs\\Sistem-Management-Masjid\\app\\Filament\\Resources\\UserResource.php' => 'App\\Filament\\Resources\\UserResource',
    0 => 'BezhanSalleh\\FilamentShield\\Resources\\RoleResource',
  ),
  'resourceDirectories' => 
  array (
    0 => 'C:\\xampp\\htdocs\\Sistem-Management-Masjid\\app\\Filament/Resources',
  ),
  'resourceNamespaces' => 
  array (
    0 => 'App\\Filament\\Resources',
  ),
  'widgets' => 
  array (
    'C:\\xampp\\htdocs\\Sistem-Management-Masjid\\app\\Filament\\Widgets\\GuruChart.php' => 'App\\Filament\\Widgets\\GuruChart',
    'C:\\xampp\\htdocs\\Sistem-Management-Masjid\\app\\Filament\\Widgets\\SantriChart.php' => 'App\\Filament\\Widgets\\SantriChart',
    'C:\\xampp\\htdocs\\Sistem-Management-Masjid\\app\\Filament\\Widgets\\StatsOverview.php' => 'App\\Filament\\Widgets\\StatsOverview',
    0 => 'Filament\\Widgets\\AccountWidget',
    1 => 'Filament\\Widgets\\FilamentInfoWidget',
  ),
  'widgetDirectories' => 
  array (
    0 => 'C:\\xampp\\htdocs\\Sistem-Management-Masjid\\app\\Filament/Widgets',
  ),
  'widgetNamespaces' => 
  array (
    0 => 'App\\Filament\\Widgets',
  ),
);